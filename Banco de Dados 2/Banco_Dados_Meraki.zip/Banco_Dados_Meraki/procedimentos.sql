# DADOS DA ESTETICISTA DONA 
INSERT INTO esteticista_geral (nome, email, telefone) VALUES
('Fernanda Lima', 'fernanda.lima@email.com', '11965432109');


#DADOS DOS PROCEDIMENTOS
INSERT INTO procedimentos (categoria, nome_procedimento, valor, id_esteticista) VALUES
('Facial', 'Limpeza de Pele', 150.00, 1),
('Corporal', 'Massagem Relaxante', 200.00, 1),
('Corporal', 'Drenagem Linfática', 180.00, 1),
('Facial', 'Peeling', 250.00, 1),
('Facial', 'Microagulhamento', 300.00, 1),
('Corporal', 'Massagem Modeladora', 220.00, 1),
('Facial', 'Hidratação Facial', 160.00, 1),
('Corporal', 'Esfoliação Corporal', 180.00, 1),
('Facial', 'Máscara Rejuvenescedora', 200.00, 1),
('Corporal', 'Banho de Lua', 210.00, 1),
('Facial', 'Limpeza Profunda', 190.00, 1);




