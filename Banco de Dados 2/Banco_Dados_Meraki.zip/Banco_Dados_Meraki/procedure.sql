#1) Procedure CRUD Transacional
DELIMITER $$

CREATE PROCEDURE sp_inserir_agendamento_procedimento(
    IN p_id_cliente INT,
    IN p_id_procedimento INT,
    IN p_id_esteticista INT,
    IN p_id_horario INT,
    OUT p_status VARCHAR(100)
)
proc:BEGIN
    DECLARE v_count INT DEFAULT 0;

    -- ERRO: caso aconteça algum problema
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SET p_status = 'Erro ao inserir agendamento.';
    END;

    START TRANSACTION;

    -- PRÉ-CONDIÇÃO: horário deve estar livre
    SELECT COUNT(*) INTO v_count
    FROM agendamentos_procedimentos
    WHERE id_horario = p_id_horario
      AND status IN ('Confirmado', 'Pendente');

    IF v_count > 0 THEN
        SET p_status = 'Horário indisponível.';
        ROLLBACK;
        LEAVE proc;
    END IF;

    -- OPERAÇÃO: inserir
    INSERT INTO agendamentos_procedimentos
    (id_cliente, id_procedimento, id_esteticista, id_horario, status)
    VALUES
    (p_id_cliente, p_id_procedimento, p_id_esteticista, p_id_horario, 'Pendente');

    COMMIT;

    -- PÓS-CONDIÇÃO
    SET p_status = 'Agendamento inserido com sucesso.';
END $$

DELIMITER ;

CALL sp_inserir_agendamento_procedimento(1, 4, 2, 15, @msg);
SELECT @msg;

# FUNCAO CALCULAR PRECO DO SERVICO

DELIMITER $$

CREATE FUNCTION calcular_preco_desconto(
    p_valor DECIMAL(10,2),
    p_desconto_percent INT
) RETURNS DECIMAL(10,2)
DETERMINISTIC
NO SQL
BEGIN
    DECLARE v_preco_final DECIMAL(10,2);

    -- Pré-condição
    IF p_valor <= 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Valor deve ser maior que zero';
    END IF;

    IF p_desconto_percent < 0 OR p_desconto_percent > 100 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Desconto inválido';
    END IF;

    -- Operação
    SET v_preco_final = p_valor * (1 - p_desconto_percent / 100);

    -- Pós-condição
    RETURN v_preco_final;
END $$

DELIMITER ;


SELECT calcular_preco_desconto(500, 10); 
SELECT calcular_preco_desconto(200, 50); 


# finalizar um agendamento de procedimento e criar automaticamente um registro do serviço concluído,
#Rotina de negócio / regra de consistência
DELIMITER $$

CREATE PROCEDURE finalizar_atendimento_procedimento(
    IN p_id_agendamento_procedimento INT,
    OUT p_id_servico INT
)
BEGIN
    DECLARE v_count INT;

    -- Pré-condição
    SELECT COUNT(*) INTO v_count
    FROM agendamentos_procedimentos
    WHERE id_agendamento_procedimento = p_id_agendamento_procedimento
      AND status != 'Concluído';

    IF v_count = 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Agendamento inexistente ou já concluído';
    END IF;

    -- Transação
    START TRANSACTION;

    -- Atualiza status do agendamento
    UPDATE agendamentos_procedimentos
    SET status = 'Concluído'
    WHERE id_agendamento_procedimento = p_id_agendamento_procedimento;

    -- Cria serviço concluído
    INSERT INTO servicos_concluidos(id_agendamento_procedimento)
    VALUES (p_id_agendamento_procedimento);

    SET p_id_servico = LAST_INSERT_ID();

    COMMIT;

    -- Pós-condição: serviço concluído criado
    SELECT 'Atendimento finalizado com sucesso.' AS mensagem;
END $$

DELIMITER ;

-- Exemplo de chamada:
CALL finalizar_atendimento_procedimento(3, @id_servico);
SELECT @id_servico;



DELIMITER $$

CREATE PROCEDURE relatorio_agendamentos_prof_direto(
    IN p_id_profissional INT,
    IN p_data_inicio DATETIME,
    IN p_data_fim DATETIME
)
proc:BEGIN
    DECLARE v_count INT DEFAULT 0;

    -- Tratamento de erro geral
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        SELECT 'Erro ao gerar relatório.' AS mensagem;
    END;

    -- Pré-condições
    IF p_id_profissional IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'ID do profissional inválido';
    END IF;

    IF p_data_inicio > p_data_fim THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Data início maior que data fim';
    END IF;

    -- Verifica se existem agendamentos
    SELECT COUNT(*) INTO v_count
    FROM agendamentos_profissionais a
    JOIN horarios_disponiveis h ON a.id_horario = h.id_horario
    WHERE a.id_profissional = p_id_profissional
      AND h.data_horario BETWEEN p_data_inicio AND p_data_fim;

    IF v_count = 0 THEN
        SELECT 'Nenhum agendamento encontrado para este período.' AS mensagem;
        LEAVE proc;
    END IF;

    -- Operação: retorna relatório diretamente
    SELECT a.id_agendamento_prof,
           c.nome AS cliente,
           h.data_horario,
           a.tipo_consulta,
           a.status
    FROM agendamentos_profissionais a
    JOIN clientes c ON a.id_cliente = c.id_cliente
    JOIN horarios_disponiveis h ON a.id_horario = h.id_horario
    WHERE a.id_profissional = p_id_profissional
      AND h.data_horario BETWEEN p_data_inicio AND p_data_fim
    ORDER BY h.data_horario;

END $$

DELIMITER ;

-- Exemplo de chamada:
CALL relatorio_agendamentos_prof_direto(2, '2025-12-01 00:00:00', '2025-12-31 23:59:59');


