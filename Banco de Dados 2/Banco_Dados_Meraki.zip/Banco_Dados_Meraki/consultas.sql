# agr- agendamentos_profissionais 
#apr-agendamentos_procedimentos
#c-clientes

#Essa consulta retorna todos os agendamentos de profissionais que estão com o status:Confimado 

SELECT 
agr.id_agendamento_prof,
c.nome AS `Nome_Cliente`,
prof.nome AS `Nome_profissional`,
prof.atuacao `Tipo_Serviço`,
hr.data_horario AS `Horario_marcado`,
agr.status AS `Status_Atual`
FROM agendamentos_profissionais agr
INNER JOIN profissionais prof ON agr.id_profissional=prof.id_profissional
INNER JOIN clientes c ON agr.id_cliente=c.id_cliente
INNER JOIN horarios_disponiveis hr ON agr.id_horario=hr.id_horario
WHERE agr.status="Confirmado";



-- Relatório completo: cliente + serviço + profissional + pagamento (somente profissionais)
SELECT 
    c.nome AS cliente,
    prof.nome AS profissional,
    prof.atuacao AS servico,
    p.tipo_pagamento,
    p.valor,
    p.status AS status_pagamento
FROM servicos_concluidos sc
INNER JOIN agendamentos_profissionais agp 
    ON sc.id_agendamento_profissional = agp.id_agendamento_prof
INNER JOIN profissionais prof 
    ON agp.id_profissional = prof.id_profissional
INNER JOIN clientes c 
    ON agp.id_cliente = c.id_cliente
INNER JOIN pagamentos p 
    ON sc.id_servico = p.id_servico
ORDER BY c.nome, prof.nome;



#Horários Ocupados vs. Livres por Profissional
SELECT 
    prof.nome AS profissional,
    hr.data_horario,
    CASE 
        WHEN agr.id_agendamento_prof IS NULL THEN 'Livre'
        ELSE 'Ocupado'
    END AS status
FROM horarios_disponiveis hr
LEFT JOIN agendamentos_profissionais agr
       ON hr.id_horario = agr.id_horario
JOIN profissionais prof
       ON hr.id_profissional = prof.id_profissional
ORDER BY prof.nome, hr.data_horario;


#Valor total faturado por procedimento dentro de um intervalo de datas
SELECT 
    prc.nome_procedimento,
    SUM(p.valor) AS total_faturado,
    COUNT(p.id_pagamento) AS total_pagamentos
FROM pagamentos p
JOIN servicos_concluidos sc
      ON p.id_servico = sc.id_servico
JOIN agendamentos_procedimentos ap
      ON sc.id_agendamento_procedimento = ap.id_agendamento_procedimento
JOIN procedimentos prc
      ON ap.id_procedimento = prc.id_procedimento
WHERE p.status = 'Pago'
  AND p.data_pagamento BETWEEN '2025-12-01' AND '2026-01-31'
GROUP BY prc.id_procedimento, prc.nome_procedimento
ORDER BY total_faturado DESC;



#identificar procedimentos mais caros e quantas vezes foram realizados
#Função de agregação + ordenação 

SELECT 
    prc.nome_procedimento,
    prc.valor AS valor_procedimento,
    COUNT(ap.id_agendamento_procedimento) AS total_realizados
FROM procedimentos prc
LEFT JOIN agendamentos_procedimentos ap
       ON prc.id_procedimento = ap.id_procedimento
GROUP BY prc.id_procedimento, prc.nome_procedimento, prc.valor
ORDER BY prc.valor DESC, total_realizados DESC;



# localizar clientes que ainda não pagaram serviços
SELECT 
    c.nome AS nome_cliente,
    prc.nome_procedimento,
    prc.valor AS valor_servico,
    p.status AS status_pagamento
FROM pagamentos p
JOIN servicos_concluidos sc 
       ON p.id_servico = sc.id_servico
JOIN agendamentos_procedimentos ap
       ON sc.id_agendamento_procedimento = ap.id_agendamento_procedimento
JOIN clientes c
       ON ap.id_cliente = c.id_cliente
JOIN procedimentos prc
       ON ap.id_procedimento = prc.id_procedimento
WHERE p.id_servico IN (
        SELECT p2.id_servico
        FROM pagamentos p2
        WHERE p2.status = 'Pendente'
);


       
# Profissionais com maior número de atendimentos
SELECT 
    prof.nome AS `profissional`,
    COUNT(agr.id_agendamento_prof) AS total_atendimentos
FROM agendamentos_profissionais agr
JOIN profissionais prof 
    ON agr.id_profissional = prof.id_profissional
WHERE agr.status = 'Concluido'
GROUP BY prof.id_profissional, prof.nome
HAVING COUNT(agr.id_agendamento_prof) > 1  
ORDER BY total_atendimentos DESC;


#Identificar clientes que fizeram mais de um tipo de procedimento em um período.
SELECT
    c.nome AS cliente,
    COUNT(apr.id_procedimento) AS total_tipos_procedimento
FROM agendamentos_procedimentos apr
INNER JOIN clientes c ON apr.id_cliente = c.id_cliente
WHERE apr.status = 'Concluido'
GROUP BY c.id_cliente, c.nome
HAVING COUNT(apr.id_procedimento) > 1
ORDER BY total_tipos_procedimento DESC;


# Faturamento por forma de pagamento
SELECT 
    tipo_pagamento,
    SUM(valor) AS total
FROM pagamentos
WHERE status = 'Pago'
GROUP BY tipo_pagamento
ORDER BY total DESC;


 