SELECT * FROM clinica_meraki.agendamentos_procedimentos
WHERE status="Confirmado";
SELECT * FROM clinica_meraki.horarios_disponiveis;

USE clinica_meraki;


-- SERVIÇOS CONCLUIDOS DE PROFISSIONAIS 
INSERT INTO servicos_concluidos (id_servico,id_agendamento_profissional, id_agendamento_procedimento) VALUES
(300, 804, NULL),
(301, 806, NULL),
(302, 810, NULL),
(303, 812, NULL),
(304, 816, NULL),
(305, 818, NULL),
(306, 822, NULL),
(307, 824, NULL),
(308, 828, NULL),
(309, 830, NULL),
(310, 834, NULL),
(311, 836, NULL),
(312, 840, NULL),
(313, 842, NULL),
(314, 846, NULL),
(315, 848, NULL),
(316, 852, NULL),
(317, 854, NULL),
(318, 858, NULL),
(319, 860, NULL),

-- SERVIÇOS CONLUIDOS PROCEDIMENTOS
(320, NULL, 100),
(321, NULL, 102),
(322, NULL, 104),
(323, NULL, 106),
(324, NULL, 108),
(325, NULL, 111),
(326, NULL, 113),
(327, NULL, 115);