
#DADOS DOS PROFISSIONAIS 

INSERT INTO profissionais (nome, telefone, email, atuacao) VALUES
-- PROFISSIONAIS DA SAÚDE
('Juliana Costa', '11921098765', 'juliana.costa@email.com', 'Manicure'),
('Felipe Souza', '11910987654', 'felipe.souza@email.com', 'Maquiador'),
('Camila Ribeiro', '11909876543', 'camila.ribeiro@email.com', 'Designer de Sobrancelhas'),
('Beatriz Santos', '11987654321', 'beatriz.santos@email.com', 'Depiladora'),
('Ana Lima', '11976549876', 'ana.lima@email.com', 'Lash Designer'),
('Lucas Andrade', '11998765432', 'lucas.andrade@email.com', 'Fisioterapia'),
('Mariana Rocha', '11987651234', 'mariana.rocha@email.com', 'Nutrição'),
('Rafael Monteiro', '11976543210', 'rafael.monteiro@email.com', 'Psicologia'),
('Paula Cardoso', '11965432109', 'paula.cardoso@email.com', 'Quiropraxia'),
('Sofia Martins', '11943210987', 'sofia.martins@email.com', 'Dermatologia'),
('Daniel Nogueira', '11932109876', 'daniel.nogueira@email.com', 'Medica Pediatra');	





