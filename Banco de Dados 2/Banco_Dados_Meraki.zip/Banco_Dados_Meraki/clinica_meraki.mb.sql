
-- ==============================================
-- BANCO DE DADOS: CLÍNICA MERAKI
-- ==============================================
DROP DATABASE IF EXISTS clinica_meraki;
CREATE DATABASE clinica_meraki CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE clinica_meraki;

-- ==============================================
-- TABELA CLIENTES
-- ==============================================
CREATE TABLE clientes (
  id_cliente INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL,
  email VARCHAR(100),
  telefone VARCHAR(20)
) ENGINE = InnoDB;

CREATE INDEX idx_clientes_nome ON clientes(nome);
CREATE INDEX idx_clientes_email ON clientes(email);

-- ==============================================
-- TABELA PROFISSIONAIS
-- ==============================================
CREATE TABLE profissionais (
  id_profissional INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL,
  telefone VARCHAR(20),
  email VARCHAR(130),
  atuacao VARCHAR(45)
) ENGINE = InnoDB;

CREATE INDEX idx_profissionais_nome ON profissionais(nome);
CREATE INDEX idx_profissionais_atuacao ON profissionais(atuacao);

-- ==============================================
-- TABELA ESTETICISTA GERAL
-- ==============================================
CREATE TABLE esteticista_geral (
  id_esteticista INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL,
  email VARCHAR(130),
  telefone VARCHAR(20)
) ENGINE = InnoDB;

-- ==============================================
-- TABELA PROCEDIMENTOS
-- ==============================================
CREATE TABLE procedimentos (
  id_procedimento INT AUTO_INCREMENT PRIMARY KEY,
  categoria VARCHAR(50) NOT NULL,
  nome_procedimento VARCHAR(100) NOT NULL,
  valor DECIMAL(10,2),
  id_esteticista INT,
  FOREIGN KEY (id_esteticista) REFERENCES esteticista_geral(id_esteticista)
) ENGINE = InnoDB;

CREATE INDEX idx_procedimentos_categoria ON procedimentos(categoria);

-- ==============================================
-- TABELA HORÁRIOS DISPONÍVEIS
-- ==============================================
CREATE TABLE horarios_disponiveis (
  id_horario INT  PRIMARY KEY,
  id_profissional INT NULL,
  id_esteticista INT NULL,
  data_horario DATETIME NOT NULL,
  FOREIGN KEY (id_profissional) REFERENCES profissionais(id_profissional),
  FOREIGN KEY (id_esteticista) REFERENCES esteticista_geral(id_esteticista),
  CONSTRAINT uc_prof_data UNIQUE (id_profissional, data_horario),
  CONSTRAINT uc_esteticista_data UNIQUE (id_esteticista, data_horario)
) ENGINE = InnoDB;

CREATE INDEX idx_horarios_data ON horarios_disponiveis(data_horario);
CREATE INDEX idx_horarios_profissional ON horarios_disponiveis(id_profissional);
CREATE INDEX idx_horarios_esteticista ON horarios_disponiveis(id_esteticista);

-- ==============================================
-- TABELA AGENDAMENTO DE PROFISSIONAIS
-- ==============================================
CREATE TABLE agendamentos_profissionais (
  id_agendamento_prof INT  PRIMARY KEY,
  id_cliente INT,
  id_profissional INT,
  id_horario INT, 
  tipo_consulta VARCHAR(100),
  status ENUM('Pendente', 'Confirmado', 'Cancelado', 'Concluído') DEFAULT 'Pendente',
  FOREIGN KEY (id_cliente) REFERENCES clientes(id_cliente),
  FOREIGN KEY (id_profissional) REFERENCES profissionais(id_profissional),
  FOREIGN KEY (id_horario) REFERENCES horarios_disponiveis(id_horario)
);

CREATE INDEX idx_agr_cliente ON agendamentos_profissionais(id_cliente);
CREATE INDEX idx_agr_profissional ON agendamentos_profissionais(id_profissional);
CREATE INDEX idx_agr_status ON agendamentos_profissionais(status);

-- ==============================================
-- TABELA AGENDAMENTO DE PROCEDIMENTOS
-- ==============================================
CREATE TABLE agendamentos_procedimentos (
  id_agendamento_procedimento INT  PRIMARY KEY,
  id_procedimento INT,
  id_esteticista INT,
  id_cliente INT,
  id_horario INT,
  status ENUM('Pendente', 'Confirmado', 'Cancelado', 'Concluído') DEFAULT 'Pendente',
  FOREIGN KEY (id_procedimento) REFERENCES procedimentos(id_procedimento),
  FOREIGN KEY (id_esteticista) REFERENCES esteticista_geral(id_esteticista),
  FOREIGN KEY (id_cliente) REFERENCES clientes(id_cliente),
  FOREIGN KEY (id_horario) REFERENCES horarios_disponiveis(id_horario)
) ENGINE = InnoDB;

CREATE INDEX idx_aproced_cliente ON agendamentos_procedimentos(id_cliente);
CREATE INDEX idx_aproced_esteticista ON agendamentos_procedimentos(id_esteticista);
CREATE INDEX idx_aproced_status ON agendamentos_procedimentos(status);

-- ==============================================
-- TABELA SERVIÇOS CONCLUÍDOS
-- ==============================================
CREATE TABLE servicos_concluidos (
   id_servico INT PRIMARY KEY,
   id_agendamento_profissional INT,
   id_agendamento_procedimento INT,
   FOREIGN KEY (id_agendamento_profissional) REFERENCES agendamentos_profissionais(id_agendamento_prof),
   FOREIGN KEY (id_agendamento_procedimento) REFERENCES agendamentos_procedimentos(id_agendamento_procedimento)
) ENGINE = InnoDB;

CREATE INDEX idx_servicos_data ON servicos_concluidos(data_conclusao);

-- ==============================================
-- TABELA PAGAMENTOS
-- ==============================================
CREATE TABLE pagamentos (
  id_pagamento INT AUTO_INCREMENT PRIMARY KEY,
  tipo_pagamento ENUM('Pix', 'Cartão', 'Dinheiro') DEFAULT 'Pix',
  valor DECIMAL(10,2),
  data_pagamento DATETIME DEFAULT CURRENT_TIMESTAMP,
  status ENUM('Pendente', 'Pago', 'Cancelado') DEFAULT 'Pendente',
  id_servico INT UNIQUE,
  FOREIGN KEY (id_servico) REFERENCES servicos_concluidos(id_servico)
) ENGINE = InnoDB;

CREATE INDEX idx_pagamentos_status ON pagamentos(status);
CREATE INDEX idx_pagamentos_data ON pagamentos(data_pagamento);

ALTER TABLE agendamentos_profissionais
ADD CONSTRAINT uc_cliente_horario UNIQUE (id_cliente, id_horario, id_profissional);

ALTER TABLE agendamentos_procedimentos
ADD CONSTRAINT uc_cliente_procedimento_horario UNIQUE (id_cliente, id_horario, id_procedimento, id_esteticista);
