

#DADOS DOS HORARIOS DIPONIVEIS DE CADA PROFISSIONAL E DONA DA CLINICA QUE É ESTETICISTA



# HORARIOS DIPONIVEIS PARA ESTETICISTA/DONA CLINICA
INSERT INTO horarios_disponiveis (id_horario, id_profissional, id_esteticista, data_horario) VALUES
-- HORÁRIOS PARA ESTETICISTA / DONA DA CLÍNICA
(1, NULL, 1, '2025-11-10 09:00:00'),
(2, NULL, 1, '2025-11-18 14:00:00'),
(3, NULL, 1, '2025-11-25 15:30:00'),
(4, NULL, 1, '2025-11-30 16:00:00'),
(5, NULL, 1, '2025-12-05 11:00:00'),
(6, NULL, 1, '2025-12-10 14:30:00'),
(7, NULL, 1, '2025-12-18 15:00:00'),
(8, NULL, 1, '2025-12-22 16:00:00'),
(9, NULL, 1, '2026-01-08 09:30:00'),
(10, NULL, 1, '2026-01-16 14:00:00'),
(11, NULL, 1, '2026-01-23 17:00:00'),
(12, NULL, 1, '2025-12-01 11:30:00'),
(13, NULL, 1, '2025-12-01 14:00:00'),
(14, NULL, 1, '2025-12-01 14:30:00'),
(15, NULL, 1, '2025-12-01 15:00:00'),
(16, NULL, 1, '2025-12-01 15:30:00'),
(17, NULL, 1, '2025-12-01 16:00:00'),

-- HORÁRIOS DISPONÍVEIS POR PROFISSIONAL
(18, 1, NULL, '2025-11-12 09:00:00'),
(19, 1, NULL, '2025-12-03 10:30:00'),
(20, 1, NULL, '2026-01-08 13:00:00'),
(21, 1, NULL, '2026-01-18 15:00:00'),

(22, 2, NULL, '2025-11-15 11:00:00'),
(23, 2, NULL, '2025-12-07 14:20:00'),
(24, 2, NULL, '2026-01-10 09:40:00'),
(25, 2, NULL, '2026-01-21 16:10:00'),

(26, 3, NULL, '2025-11-18 10:00:00'),
(27, 3, NULL, '2025-12-05 11:45:00'),
(28, 3, NULL, '2026-01-11 14:30:00'),
(29, 3, NULL, '2026-01-22 15:40:00'),

(30, 4, NULL, '2025-11-20 09:30:00'),
(31, 4, NULL, '2025-12-09 13:15:00'),
(32, 4, NULL, '2026-01-08 15:50:00'),
(33, 4, NULL, '2026-01-25 17:00:00'),

(34, 5, NULL, '2025-11-22 10:10:00'),
(35, 5, NULL, '2025-12-11 12:40:00'),
(36, 5, NULL, '2026-01-12 14:50:00'),
(37, 5, NULL, '2026-01-26 16:20:00'),

(38, 6, NULL, '2025-11-25 09:00:00'),
(39, 6, NULL, '2025-12-15 10:30:00'),
(40, 6, NULL, '2026-01-14 13:00:00'),
(41, 6, NULL, '2026-01-27 15:30:00'),

(42, 7, NULL, '2025-11-27 09:40:00'),
(43, 7, NULL, '2025-12-17 11:10:00'),
(44, 7, NULL, '2026-01-15 14:00:00'),
(45, 7, NULL, '2026-01-28 16:10:00'),

(46, 8, NULL, '2025-11-29 10:20:00'),
(47, 8, NULL, '2025-12-19 12:00:00'),
(48, 8, NULL, '2026-01-16 15:40:00'),
(49, 8, NULL, '2026-01-29 17:10:00'),

(50, 9, NULL, '2025-11-30 09:50:00'),
(51, 9, NULL, '2025-12-21 14:10:00'),
(52, 9, NULL, '2026-01-18 15:30:00'),
(53, 9, NULL, '2026-01-30 16:50:00'),

(54, 10, NULL, '2025-11-13 10:00:00'),
(55, 10, NULL, '2025-12-08 11:35:00'),
(56, 10, NULL, '2026-01-09 14:20:00'),
(57, 10, NULL, '2026-01-19 15:45:00'),

(58, 11, NULL, '2025-11-17 09:20:00'),
(59, 11, NULL, '2025-12-10 10:50:00'),
(60, 11, NULL, '2026-01-11 13:40:00'),
(61, 11, NULL, '2026-01-24 16:30:00'),

-- BLOCOS DE 2027
(62, 1, NULL, '2027-02-03 09:00:00'),
(63, 1, NULL, '2027-02-10 10:30:00'),
(64, 1, NULL, '2027-02-17 13:00:00'),

(65, 2, NULL, '2027-02-04 11:00:00'),
(66, 2, NULL, '2027-02-12 14:20:00'),
(67, 2, NULL, '2027-02-19 09:40:00'),

(68, 3, NULL, '2027-02-05 10:00:00'),
(69, 3, NULL, '2027-02-13 11:45:00'),
(70, 3, NULL, '2027-02-20 14:30:00'),

(71, 4, NULL, '2027-02-06 09:30:00'),
(72, 4, NULL, '2027-02-14 13:15:00'),
(73, 4, NULL, '2027-02-21 15:50:00'),

(74, 5, NULL, '2027-02-07 10:10:00'),
(75, 5, NULL, '2027-02-15 12:40:00'),
(76, 5, NULL, '2027-02-22 14:50:00'),

(77, 6, NULL, '2027-02-08 09:00:00'),
(78, 6, NULL, '2027-02-16 10:30:00'),
(79, 6, NULL, '2027-02-23 13:00:00'),

(80, 7, NULL, '2027-02-09 09:40:00'),
(81, 7, NULL, '2027-02-17 11:10:00'),
(82, 7, NULL, '2027-02-24 14:00:00'),

-- BLOCOS DE 2028
(83, 8, NULL, '2028-02-10 10:20:00'),
(84, 8, NULL, '2028-02-18 12:00:00'),
(85, 8, NULL, '2028-02-25 15:40:00'),

(86, 9, NULL, '2028-02-11 09:50:00'),
(87, 9, NULL, '2028-02-19 14:10:00'),
(88, 9, NULL, '2028-02-26 15:30:00'),

(89, 10, NULL, '2028-02-12 10:00:00'),
(90, 10, NULL, '2028-02-20 11:35:00'),
(91, 10, NULL, '2028-02-27 14:20:00');



INSERT INTO agendamentos_profissionais 
(id_agendamento_prof, id_cliente, id_profissional, id_horario, tipo_consulta, status) VALUES

-- Profissional 1 – Manicure
(801, 1, 1, 18, 'Manicure em Gel', 'Confirmado'),
(802, 1, 1, 19, 'Esmaltação simples', 'Pendente'),
(803, 1, 1, 20, 'Spa das Mãos', 'Confirmado'),
(804, 1, 1, 62, 'Manicure Mão', 'Concluído'),
(805, 1, 1, 63, 'Manicure Pés', 'Pendente'),
(806, 1, 1, 64, 'Manicure Manutenção', 'Concluído'),

-- Profissional 2 – Felipe (Maquiador)
(807, 2, 2, 22, 'Maquiagem Social', 'Confirmado'),
(808, 2, 2, 23, 'Maquiagem Artística', 'Pendente'),
(809, 2, 2, 24, 'Maquiagem Madrinha', 'Confirmado'),
(810, 2, 2, 65, 'Maquiador', 'Concluído'),
(811, 2, 2, 66, 'Maquiador', 'Pendente'),
(812, 2, 2, 67, 'Maquiador', 'Concluído'),

-- Profissional 3 – Camila (Designer Sobrancelhas)
(813, 3, 3, 26, 'Design de Sobrancelhas', 'Confirmado'),
(814, 3, 3, 27, 'Design + Henna', 'Pendente'),
(815, 3, 3, 28, 'Sobrancelha fio a fio', 'Confirmado'),
(816, 3, 3, 68, 'Designer de Sobrancelhas', 'Concluído'),
(817, 3, 3, 69, 'Designer de Sobrancelhas', 'Pendente'),
(818, 3, 3, 70, 'Designer de Sobrancelhas', 'Concluído'),

-- Profissional 4 – Beatriz (Depiladora)
(819, 4, 4, 30, 'Depilação Completa', 'Confirmado'),
(820, 4, 4, 31, 'Depilação Meia Perna', 'Pendente'),
(821, 4, 4, 32, 'Depilação Axilas', 'Confirmado'),
(822, 4, 4, 71, 'Depiladora', 'Concluído'),
(823, 4, 4, 72, 'Depiladora', 'Pendente'),
(824, 4, 4, 73, 'Depiladora', 'Concluído'),

-- Profissional 5 – Ana (Lash Designer)
(825, 5, 5, 34, 'Extensão de Cílios', 'Confirmado'),
(826, 5, 5, 35, 'Manutenção de Cílios', 'Pendente'),
(827, 5, 5, 36, 'Volume Russo', 'Confirmado'),
(828, 5, 5, 74, 'Lash Designer', 'Concluído'),
(829, 5, 5, 75, 'Lash Designer', 'Pendente'),
(830, 5, 5, 76, 'Lash Designer', 'Concluído'),

-- Profissional 6 – Lucas (Fisioterapia)
(831, 6, 6, 38, 'Sessão de Fisioterapia', 'Confirmado'),
(832, 6, 6, 39, 'Avaliação Postural', 'Pendente'),
(833, 6, 6, 40, 'Fisioterapia Ortopédica', 'Confirmado'),
(834, 6, 6, 77, 'Fisioterapia', 'Concluído'),
(835, 6, 6, 78, 'Fisioterapia', 'Pendente'),
(836, 6, 6, 79, 'Fisioterapia', 'Concluído'),

-- Profissional 7 – Mariana (Nutrição)
(837, 7, 7, 42, 'Avaliação Nutricional', 'Confirmado'),
(838, 7, 7, 43, 'Plano Alimentar', 'Pendente'),
(839, 7, 7, 44, 'Consulta de Retorno', 'Confirmado'),
(840, 7, 7, 80, 'Nutrição', 'Concluído'),
(841, 7, 7, 81, 'Nutrição', 'Pendente'),
(842, 7, 7, 82, 'Nutrição', 'Concluído'),

-- Profissional 8 – Rafael (Psicologia)
(843, 8, 8, 46, 'Sessão de Psicologia', 'Confirmado'),
(844, 8, 8, 47, 'Acompanhamento Psicológico', 'Pendente'),
(845, 8, 8, 48, 'Terapia Cognitiva', 'Confirmado'),
(846, 8, 8, 83, 'Psicologia', 'Concluído'),
(847, 8, 8, 84, 'Psicologia', 'Pendente'),
(848, 8, 8, 85, 'Psicologia', 'Concluído'),

-- Profissional 9 – Paula (Quiropraxia)
(849, 9, 9, 50, 'Sessão de Quiropraxia', 'Confirmado'),
(850, 9, 9, 51, 'Ajuste Vertebral', 'Pendente'),
(851, 9, 9, 52, 'Alinhamento Postural', 'Confirmado'),
(852, 9, 9, 86, 'Quiropraxia', 'Concluído'),
(853, 9, 9, 87, 'Quiropraxia', 'Pendente'),
(854, 9, 9, 88, 'Quiropraxia', 'Concluído'),

-- Profissional 10 – Sofia (Dermatologia)
(855, 10, 10, 54, 'Consulta Dermatológica', 'Confirmado'),
(856, 10, 10, 55, 'Tratamento de Pele', 'Pendente'),
(857, 10, 10, 56, 'Dermatologia Clínica', 'Confirmado'),
(858, 10, 10, 89, 'Dermatologia', 'Concluído'),
(859, 10, 10, 90, 'Dermatologia', 'Pendente'),
(860, 10, 10, 91, 'Dermatologia', 'Concluído'),

-- Profissional 11 – Daniel (Pediatra)
(861, 11, 11, 58, 'Consulta Pediátrica', 'Confirmado'),
(862, 11, 11, 59, 'Retorno Pediatria', 'Pendente'),
(863, 11, 11, 60, 'Acompanhamento Infantil', 'Confirmado');




#DADOS AGENDAMENTOS DE PROCEDIMENTOS 

 
INSERT INTO agendamentos_procedimentos 
(id_agendamento_procedimento, id_procedimento, id_esteticista, id_cliente, id_horario, status) VALUES
(100, 1, 1, 1, 1, 'Concluído'),
(101, 4, 1, 1, 2, 'Confirmado'),
(102, 2, 1, 2, 3, 'Concluído'),
(103, 2, 1, 2, 4, 'Confirmado'),
(104, 3, 1, 3, 5, 'Concluído'),
(105, 1, 1, 4, 6, 'Confirmado'),
(106, 7, 1, 4, 7, 'Concluído'),
(107, 5, 1, 5, 8, 'Confirmado'),
(108, 6, 1, 6, 9, 'Concluído'),
(109, 6, 1, 6, 10, 'Confirmado'),
(110, 8, 1, 7, 11, 'Confirmado'),
(111, 9, 1, 8, 12, 'Concluído'),
(112, 10, 1, 9, 13, 'Confirmado'),
(113, 11, 1, 10, 14, 'Concluído'),
(114, 3, 1, 11, 15, 'Confirmado'),
(115, 1, 1, 12, 16, 'Concluído'),
(116, 4, 1, 13, 17, 'Confirmado');  


