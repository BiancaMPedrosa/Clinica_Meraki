

-- Essa transação serve para garantir que todas as operações relacionadas ao pagamento de um serviço sejam feitas de forma segura e consistente.

DELIMITER $$
DROP PROCEDURE IF EXISTS processar_pagamento;
CREATE PROCEDURE processar_pagamento (
    IN p_tipo_pagamento ENUM('Pix','Cartão','Dinheiro'),
    IN p_valor DECIMAL(10,2),
    IN p_id_servico INT,
    OUT p_id_pagamento INT
)
BEGIN
    DECLARE v_count INT DEFAULT 0;
    DECLARE v_status ENUM('Pendente','Pago','Cancelado');

    -- =====================
    -- PRÉ-CONDIÇÕES
    -- =====================
    IF p_valor <= 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'O valor deve ser maior que zero.';
    END IF;

    SELECT COUNT(*) INTO v_count
    FROM servicos_concluidos
    WHERE id_servico = p_id_servico;

    IF v_count = 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Serviço inexistente.';
    END IF;

    -- =====================
    -- TRANSAÇÃO
    -- =====================
    START TRANSACTION;

    -- Verifica se já existe pagamento
    SELECT id_pagamento, status INTO @existing_id, @existing_status
    FROM pagamentos
    WHERE id_servico = p_id_servico
    LIMIT 1;

    IF @existing_id IS NULL THEN
        -- Não existe: cria pagamento novo
        INSERT INTO pagamentos(tipo_pagamento, valor, id_servico, status)
        VALUES (p_tipo_pagamento, p_valor, p_id_servico, 'Pago');

        SET p_id_pagamento = LAST_INSERT_ID();
        SET @msg = 'Pagamento criado com sucesso.';

    ELSEIF @existing_status = 'Pendente' THEN
        -- Existe e está Pendente: atualiza para Pago
        UPDATE pagamentos
        SET status = 'Pago', tipo_pagamento = p_tipo_pagamento, valor = p_valor
        WHERE id_pagamento = @existing_id;

        SET p_id_pagamento = @existing_id;
        SET @msg = 'Pagamento pendente atualizado para Pago.';

    ELSE
        -- Já está Pago ou Cancelado: não altera
        SET p_id_pagamento = @existing_id;
        SET @msg = CONCAT('Pagamento já está ', @existing_status, ', nenhuma alteração feita.');
    END IF;

    COMMIT;

    -- =====================
    -- PÓS-CONDIÇÃO
    -- =====================
    SELECT @msg AS mensagem;

END $$

DELIMITER ;

CALL processar_pagamento('Pix', 250.00, 9, @id_pagamento);
SELECT @id_pagamento;
SELECT * FROM pagamentos WHERE id_pagamento = @id_pagamento;

