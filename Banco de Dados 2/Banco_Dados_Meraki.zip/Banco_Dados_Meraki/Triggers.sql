CREATE TABLE log_agendamentos (
    id_log INT AUTO_INCREMENT PRIMARY KEY,
    id_agendamento INT,
    status_antigo VARCHAR(20),
    status_novo VARCHAR(20),
    data_modificacao DATETIME,
    usuario VARCHAR(50)
);

DELIMITER $$
CREATE TRIGGER trg_log_status_agendamento
AFTER UPDATE ON agendamentos_profissionais
FOR EACH ROW
BEGIN
    IF OLD.status <> NEW.status THEN
        INSERT INTO log_agendamentos (id_agendamento, status_antigo, status_novo, data_modificacao, usuario)
        VALUES (OLD.id_agendamento_prof, OLD.status, NEW.status, NOW(), CURRENT_USER());
    END IF;
END $$ ;
DELIMITER ;

SELECT *FROM log_agendamentos;
INSERT INTO  log_agendamentos (id_agendamento, status_antigo, status_novo, data_modificacao, usuario) VALUES(21,"Pendente","Concluido",'2026-01-19 15:00:00',"eve@");

# Impedir excluir agendamento que já foi concluído
DELIMITER $$

CREATE TRIGGER trg_bloqueia_exclusao_agendamento
BEFORE DELETE ON agendamentos_profissionais
FOR EACH ROW
BEGIN
    IF OLD.status = 'Concluido' THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Não é permitido excluir um agendamento concluído.';
    END IF;
END$$

DELIMITER ;

DELETE FROM agendamentos_profissionais agr
WHERE agr.status="Concluido";

-- Dispara assim que crio um agendamento concluido , vai para tabela servico_concluidos

DELIMITER $$
DROP TRIGGER IF EXISTS trg_agendamento_prof_concluido;
CREATE TRIGGER trg_agendamento_prof_concluido
AFTER UPDATE ON agendamentos_profissionais
FOR EACH ROW
BEGIN
    -- Se o status mudou para concluído
    IF NEW.status = 'Concluido' AND OLD.status <> 'Concluido' THEN
        INSERT INTO servicos_concluidos (data_conclusao, id_agendamento_profissional)
        VALUES (NOW(), NEW.id_agendamento_prof);
    END IF;
END $$

DELIMITER ;



# Dispara assim que crio um agendamento com status concluido , vai para tabela servico_concluidos

DELIMITER $$

CREATE TRIGGER trg_procedimentos_concluidos
AFTER UPDATE ON agendamentos_procedimentos
FOR EACH ROW
BEGIN
    -- Só insere na tabela de serviços concluídos se o status mudou para 'Concluído'
    IF NEW.status = 'Concluído' AND OLD.status != 'Concluído' THEN
        INSERT INTO servicos_concluidos(id_agendamento_procedimento)
        VALUES (NEW.id_agendamento_procedimento);
    END IF;
END $$

DELIMITER ;

UPDATE agendamentos_procedimentos
SET status = 'Concluído'
WHERE id_agendamento_procedimento=10;


SHOW TRIGGERS;