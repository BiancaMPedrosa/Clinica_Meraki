
-- uso :permite visualizar o faturamento total de cada mes  e o número de pagamentos
CREATE VIEW vw_faturamento_mensal AS
SELECT 
    DATE_FORMAT(p.data_pagamento, '%Y-%m') AS mes,
    SUM(p.valor) AS total_faturado,
    COUNT(p.id_pagamento) AS total_pagamentos
FROM pagamentos p
WHERE p.status = 'Pago'
GROUP BY DATE_FORMAT(p.data_pagamento, '%Y-%m')
ORDER BY mes;



-- uso: Mostra faturamento e quantidade de pagamentos por procedimento.
CREATE VIEW vw_relatorio_faturamento AS
SELECT 
    prc.nome_procedimento,
    SUM(p.valor) AS total_faturado,
    COUNT(p.id_pagamento) AS total_pagamentos
FROM pagamentos p
JOIN servicos_concluidos sc
      ON p.id_servico = sc.id_servico
JOIN agendamentos_procedimentos ap
      ON sc.id_agendamento_procedimento = ap.id_agendamento_procedimento
JOIN procedimentos prc
      ON ap.id_procedimento = prc.id_procedimento
WHERE p.status = 'Pago'
GROUP BY prc.id_procedimento, prc.nome_procedimento;


SELECT * FROM vw_faturamento_mensal;
SELECT * FROM vw_relatorio_faturamento;

-- Uso: Permite visualizar agendamentos e serviços sem expor email ou telefone
-- ==============================================
CREATE OR REPLACE VIEW vw_agendamentos_seguro AS
SELECT 
    c.nome AS cliente,
    prof.nome AS profissional,
    prof.atuacao AS funcao,
    hr.data_horario,
    agr.status AS status_agendamento,
    p.status AS status_pagamento
FROM agendamentos_profissionais agr
LEFT JOIN clientes c ON agr.id_cliente = c.id_cliente
LEFT JOIN profissionais prof ON agr.id_profissional = prof.id_profissional
LEFT JOIN horarios_disponiveis hr ON agr.id_horario = hr.id_horario
LEFT JOIN servicos_concluidos sc ON agr.id_agendamento_prof = sc.id_agendamento_profissional
LEFT JOIN pagamentos p ON sc.id_servico = p.id_servico;




-- View Analítica: Faturamento por Profissional
-- Uso: Permite análise de desempenho financeiro e número de serviços realizados por profissional
-- ==============================================
CREATE OR REPLACE VIEW vw_faturamento_profissional AS
SELECT 
    prof.id_profissional,
    prof.nome AS profissional,
    DATE_FORMAT(hr.data_horario, '%Y-%m') AS mes_faturamento,
    SUM(p.valor) AS total_faturado,
    COUNT(sc.id_servico) AS total_servicos
FROM profissionais prof
LEFT JOIN agendamentos_profissionais agr 
    ON prof.id_profissional = agr.id_profissional
LEFT JOIN servicos_concluidos sc 
    ON agr.id_agendamento_prof = sc.id_agendamento_profissional
LEFT JOIN pagamentos p 
    ON sc.id_servico = p.id_servico AND p.status = 'Pago'
LEFT JOIN horarios_disponiveis hr 
    ON agr.id_horario = hr.id_horario
WHERE sc.id_servico IS NOT NULL
GROUP BY prof.id_profissional, prof.nome, mes_faturamento
ORDER BY mes_faturamento, total_faturado DESC;
